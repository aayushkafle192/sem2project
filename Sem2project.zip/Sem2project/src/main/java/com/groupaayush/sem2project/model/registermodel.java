/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.groupaayush.sem2project.model;

/**
 *
 * @author Aayush Kafle
 */
public class registermodel {
    private String email;
    private String password;
    
    public registermodel(String password, String email){
        this.password = password;
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public String getEmail() {
        return email;
    }
    
}
