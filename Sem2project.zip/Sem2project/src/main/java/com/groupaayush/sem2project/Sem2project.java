/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.groupaayush.sem2project;

import com.groupaayush.sem2project.dao.Authdao;
import com.groupaayush.sem2project.model.registermodel;
import com.groupaayush.sem2project.view.Login;
import com.groupaayush.sem2project.view.signup;

/**
 *
 * @author Aayush Kafle
 */
public class Sem2project {

    public static void main(String[] args) {
        signup rs=new signup();
        rs.setVisible(true);
        Authdao auth=new Authdao();
        String email="test@test.com";
        String password="password";
        registermodel rn = new registermodel(password,email);
      
        
        boolean result=auth.register(rn);
        if(result==true){
            System.out.println("Created user");
        }
//        Login l = new Login();
//        l.setVisible(true);
//        l.pack();
//        l.setLocationRelativeTo(null);
           
        
        
        
        
        
    }
}
