/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.groupaayush.sem2project.dao;

import com.groupaayush.sem2project.database.mysqlconnection;
import com.groupaayush.sem2project.model.registermodel;
import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 *
 * @author Aayush Kafle
 */
public class Authdao extends mysqlconnection {
     public boolean register(registermodel registermodel){
        try {
            String sql = "INSERT INTO login(password, email) VALUES (?,?)";

            try (Connection conn = openConnection(); 
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                
                ps.setString(1, registermodel.getPassword());
                ps.setString(2, registermodel.getEmail());

                int result = ps.executeUpdate();
                return result != -1;
            }
        } catch (Exception e) {
            System.out.println(e);
            return false;
        }
    }
     
    
}
